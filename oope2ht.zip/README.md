## Last Oope Task (L.O.T.)

Ohjelma on yksinkertainen tekstikokoelma uutisille tai vitseille. 
[Tähän tulee lisää tekstiä]